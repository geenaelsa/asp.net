<html>
<body>
<div>
<a href="login">Login</a>
<a href="registration">Registration</a>
<a href="index">Index</a>
</div>
<?php echo $__env->yieldContent('content'); ?>

</body>

</html>