<html>
<body>
<div>
<a href="login">Login</a>
<a href="registration">Registration</a>
<a href="index">Index</a>
</div>
@yield('content')

</body>

</html>